#![no_main]

#[macro_use] extern crate libfuzzer_sys;
extern crate zip;

fuzz_target!(|data| {
    let mut reader = std::io::Cursor::new(data);
    let mut archive = if let Ok(x) = zip::ZipArchive::new(reader) { x } else { return; };

    for i in 0..archive.len() {
        use std::io::prelude::*;

        let mut file = archive.by_index(i).unwrap();
        assert!(file.bytes().count() > 0);
    }
});
